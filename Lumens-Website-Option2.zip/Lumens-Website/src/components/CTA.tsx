export default function CTA(){
return <section className='p-10 text-center'><h2 className='text-3xl font-bold'>Need Industrial Solutions?</h2></section>
}
