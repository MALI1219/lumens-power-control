export default function WhyChoose(){
return <section className='p-10 bg-slate-900 text-white'><h2 className='text-3xl font-bold'>Why Choose Lumens</h2></section>
}
