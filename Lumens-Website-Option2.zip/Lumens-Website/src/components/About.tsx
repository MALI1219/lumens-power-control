export default function About(){
return <section className='p-10'><h2 className='text-3xl font-bold'>About Lumens</h2><p className='mt-4'>Powering industries with engineering excellence.</p></section>
}
