export default function Industries(){
return <section className='p-10'><h2 className='text-3xl font-bold'>Industries We Serve</h2></section>
}
