export default function Products(){
return <section className='p-10'><h2 className='text-3xl font-bold'>Products</h2><p>LT Panel, PCC, MCC, APFC, HT Panels</p></section>
}
