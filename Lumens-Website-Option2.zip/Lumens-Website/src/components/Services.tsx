export default function Services(){
return <section className='p-10'><h2 className='text-3xl font-bold'>Our Services</h2><p>Panel Manufacturing | Automation | Wiring | Maintenance</p></section>
}
