export default function Hero(){
return <section className='min-h-screen bg-slate-900 text-white flex items-center px-8'>
<div><h1 className='text-5xl font-bold'>Industrial Electrical Solutions & Automation Experts</h1>
<p className='mt-5'>Lumens Power Control delivers panels, automation and industrial electrical solutions.</p>
<button className='mt-6 bg-blue-600 px-6 py-3 rounded'>Request Quote</button>
</div></section>
}
