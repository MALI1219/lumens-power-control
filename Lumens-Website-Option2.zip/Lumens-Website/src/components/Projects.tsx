export default function Projects(){
return <section className='p-10'><h2 className='text-3xl font-bold'>Projects Gallery</h2></section>
}
