export const metadata={title:'Lumens Power Control'};
export default function Layout({children}:{children:React.ReactNode}){return <html><body>{children}</body></html>}
