import Hero from '@/components/Hero';
import About from '@/components/About';
import Services from '@/components/Services';
import Products from '@/components/Products';
import Industries from '@/components/Industries';
import Projects from '@/components/Projects';
import WhyChoose from '@/components/WhyChoose';
import CTA from '@/components/CTA';

export default function Home(){
 return <main><Hero/><About/><Services/><Products/><Industries/><Projects/><WhyChoose/><CTA/></main>
}
