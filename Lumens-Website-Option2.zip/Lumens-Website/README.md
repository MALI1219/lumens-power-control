# Lumens Website

Next.js + Tailwind CSS industrial website starter.

Run:
npm install
npm run dev

Replace demo images inside public/images with real Lumens photos.
